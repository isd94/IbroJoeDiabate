/* 
Activité : jeu de devinette
*/

// NE PAS MODIFIER OU SUPPRIMER LES LIGNES CI-DESSOUS
// COMPLETEZ LE PROGRAMME UNIQUEMENT APRES LE TODO

console.log("Bienvenue dans ce jeu de devinette !");

// Cette ligne génère aléatoirement un nombre entre 1 et 100
var solution = Math.floor(Math.random() * 100) + 1;

// Décommentez temporairement cette ligne pour mieux vérifier le programme
//console.log("(La solution est " + solution + ")");

// TODO : complétez le programme

var nbrEssaie = 6;
var essai =1

// Tanque le nombre d'essai est inférieure ou égale à 6, il a une possibilté encore de jouer.
// When the number of tests is less than or equal to 6, it has a possibility of playing again.
while(essai <= nbrEssaie){
       var nombre = Number(prompt("Veuillez saisir le nombre")); // saisie du nombre à deviner. Entering the number to guess.

            switch (essai) {
            case 1: // Premier essai. Ensuite vérification si le nombre saisi correspond à la valeur générer.
                    // First try. Then check if the number entered corresponds to the generate value.
                    if(nombre < solution ){
                        console.log("Essaie numéro " + essai);
                        console.log(nombre + " " + "est trop petit");
           
                    } else if(nombre > solution){
                       console.log("Essaie numéro " + essai);
                       console.log(nombre + " " + "est trop grand");
                     
                     }else if (nombre === solution){
                         console.log("Essaie numéro " + essai);
                         console.log("Bravo !" + " " + nombre + "est la bonne réponse.");
                     }
                       essai++;
            break;
            case 2: // Deuxième essai. Ensuite vérification si le nombre saisi correspond à la valeur générer.
                    // Second trial. Then check if the number entered corresponds to the generate value.
                    if(nombre < solution ){
                        console.log("Essaie numéro " + essai);
                        console.log(nombre + " " + "est trop petit");
           
                    } else if(nombre > solution){
                       console.log("Essaie numéro " + essai);
                       console.log(nombre + " " + "est trop grand");
                     
                     }else if (nombre === solution){
                         console.log("Essaie numéro " + essai);
                         console.log("Bravo !" + " " + nombre + "est la bonne réponse.");
                     }
                       essai++;
            break;
            case 3: // Troisième essai. Ensuite vérification si le nombre saisi correspond à la valeur générée.
                    // Third try. Then check if the number entered corresponds to the generated value
                    if(nombre < solution ){
                        console.log("Essaie numéro " + essai);
                        console.log(nombre + " " + "est trop petit");
           
                    } else if(nombre > solution){
                       console.log("Essaie numéro " + essai);
                       console.log(nombre + " " + "est trop grand");
                     
                     }else if (nombre === solution){
                         console.log("Essaie numéro " + essai);
                         console.log("Bravo !" + " " + nombre + "est la bonne réponse.");
                     }
                       essai++;
            break;
            case 4: // Quatrième essai. Ensuite vérification si le nombre saisi correspond à la valeur générée.
                    // Fourth try. Then check if the number entered corresponds to the generate value.
                    if(nombre < solution ){
                        console.log("Essaie numéro " + essai);
                        console.log(nombre + " " + "est trop petit");
           
                    }else if(nombre > solution){
                       console.log("Essaie numéro " + essai);
                       console.log(nombre + " " + "est trop grand");
                     
                     }else if (nombre === solution){
                         console.log("Essaie numéro " + essai);
                         console.log("Bravo !" + " " + nombre + "est la bonne réponse.");
                     }
                       essai++;
            break;
            case 5: // Cinquième et avant dernier essai. Ensuite vérification si le nombre saisi correspond à la valeur générée.
                    // Fifth and penultimate test. Then check if the number entered corresponds to the generate value.
                    console.log("Attention ! Il ne vous reste plus qu'un seul essai");
                    console.log("Reflechissez bien avant de taper cette fois !");
                    if(nombre < solution ){
                        console.log("Essaie numéro " + essai);
                        console.log(nombre + " " + "est trop petit");
           
                    }else if(nombre > solution){
                       console.log("Essaie numéro " + essai);
                       console.log(nombre + " " + "est trop grand");
                     
                     }else if (nombre === solution){
                         console.log("Essaie numéro " + essai);
                         console.log("Bravo !" + " " + nombre + "est la bonne réponse.");
                     }
                       essai++;
                         
            break;
            case 6: // Dernier essai. Ensuite vérification si le nombre saisi correspond à la valeur générée.
                    // Last test. Then check if the number entered corresponds to the generate value.
                    if(nombre !== solution){
                       console.log("Tentative terminée, vous avez perdu!");
                       console.log("(La solution est " + solution + ")");
                     
                    }else if(nombre === solution){
                         console.log("Essaie numéro " + essai);
                         console.log("Bravo !" + " " + nombre + "est la bonne réponse.");
                    }
                      essai++;
            break;
            
            default:
                console.log("Tentative terminée, vous avez perdu!");
                console.log("(La solution est " + solution + ")");
            }
                    

      }
                     
